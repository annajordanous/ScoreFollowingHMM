Solo = readmidi('DanseMacabreBari.mid');
Danse = readmidi('DanseMacabre.mid');

No_of_beats_in_solo = Solo(length(Solo), 1);
No_of_beats_in_accomp = Danse(length(Danse), 1);
No_of_state_obs = floor((min(No_of_beats_in_solo, No_of_beats_in_accomp) * 2) - 1);

% Extract score version of the Performer's line, where
% one row of the Performance array == one half beat of the solo line

MIDI_Counter = 1;

for I = 0:No_of_state_obs
    Ith_counter = I+1;
    % Either the next event happens in this state or it does not
    if (2*Solo(MIDI_Counter, 1)) == I
        Performance(Ith_counter) = Solo(MIDI_Counter, 4);   % Note Pitch
        MIDI_Counter = MIDI_Counter+1;
    else Performance(Ith_counter) = 0;  % Dummy value (MIDI values range from 0-127)
    end
    
end

Performance = transpose(Performance);


% Do the same for the Accompaniment score, where
% one row of the Accomp array == one half beat of the accompaniment

MIDI_Counter = 1;

for I = 0:No_of_state_obs
    Ith_counter = I+1;
    J = 1;
    
    % Either the next event happens in this state or it does not
    if (2*Danse(MIDI_Counter, 1)) ~= I
        Accomp(Ith_counter, J) = 0;  % Dummy value (MIDI values range from 0-127)
    else 
        while (2*Danse(MIDI_Counter, 1)) == I       
    % use a while loop here because there may be several events starting on any one beat
            Accomp(Ith_counter, J) = Danse(MIDI_Counter, 4);   % Note Pitch
            MIDI_Counter = MIDI_Counter + 1;
            J = J + 1;
        end
    end
    while (2*Danse(MIDI_Counter, 1)) < I        % Just in case
        MIDI_Counter = MIDI_Counter + 1;
    end
end


% Add ghost states and state indices to the state lists for the accompaniment
for I = 1:(length(Accomp)*2)
    if mod(I, 2) == 1   % odd-numbered state therefore NORMAL state
        Score(I, :) = [(I-1) Accomp(ceil(I/2), :)];
    else
        Score(I, 1) = I-1;
        Score(I, 2) = 128;
    end
end