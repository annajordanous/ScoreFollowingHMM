MIDI_rows = length(Solo);
MIDI_cols = length(Solo(1, :));

No_of_beats = Solo(MIDI_rows, 1);

for I = 1:MIDI_rows;
    Note_onset  = ((ceil(Solo(I, 1))+1)*2)-1;
    Note_length = ceil(Solo(I, 2))*2;
    Note_off = Note_onset + Note_length;
    Note_pitch  = Solo(I, 4);
    
    for J = Note_onset:Note_off
        Performance(J) = Note_pitch;
    end
end

Performance = transpose(Performance);
