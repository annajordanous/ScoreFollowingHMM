MIDI_rows = length(solo);
MIDI_cols = length(solo(1, :));

no_of_beats = solo(MIDI_rows, 1);

% Extract the notes that occur in the solo on the start of each beat
% and store in the array perform (each new row is a new beat)
% NB It is assumed that the solo line is monophonic

MIDI_counter = 1;
for I = 0:no_of_beats
    Ith_in_array = I+1;
    while solo(MIDI_counter, 1) < I
        MIDI_counter = MIDI_counter+1;
    end
    if solo(MIDI_counter, 1) == I
        performance(Ith_in_array) = solo(MIDI_counter, 4);
        MIDI_counter = MIDI_counter+1;
    else performance(Ith_in_array) = performance(I);         
    end
end
performance = performance';

% Do the same for the accompaniment except the accomp
% can have (for now) the information for each half beat, 
% in comparison to the info taken for each performed full beat
% so each row is representative of half a beat

MIDI_counter = 1;
no_of_halfbeats = no_of_beats * 2;
for I = 0:no_of_halfbeats
    Ith_in_array = I+1;
    J = 1;
    marker = danse(MIDI_counter, 1) * 2;
%    while marker < I
%       MIDI_counter = MIDI_counter+1;
%        marker = danse(MIDI_counter, 1) * 2;
%    end
    if marker > I 
            accomp(Ith_in_array, :) = accomp(I, :);        
    else while marker == I       % As accompaniment may be polyphonic
        accomp(Ith_in_array, J) = danse(MIDI_counter, 4);
        MIDI_counter = MIDI_counter+1;
        marker = danse(MIDI_counter, 1)*2;
        J = J+1;
        end
    end
end